
<div class="signature">
    <table class="signature-table">
        <tr>
            <td colspan="<?php echo e(max(count($signature['sections']), 1)); ?>" class="place-date"><?php echo e($signature['place_date']); ?></td>
        </tr>
        <tr>
            <?php $__empty_1 = true; $__currentLoopData = $signature['sections']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <td style="width: <?php echo e(100 / count($signature['sections'])); ?>%">
                    <div class="signature-label"><?php echo e($section['label']); ?></div>
                    <table class="signers">
                        <tr>
                            <?php $__currentLoopData = $section['signers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $signer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td style="width: <?php echo e(100 / count($section['signers'])); ?>%">
                                    <div class="signer-position"><?php echo e($signer['position']); ?></div>
                                    <div class="signing-space"></div>
                                    <div class="signer-name"><?php echo e($signer['name']); ?></div>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </table>
                </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <td>&nbsp;</td>
            <?php endif; ?>
        </tr>
    </table>
</div>
<?php /**PATH E:\Project\PTPN\agrowisata-mestakara\apps\mestakara-hr\api\resources\views/payroll/_signatures.blade.php ENDPATH**/ ?>