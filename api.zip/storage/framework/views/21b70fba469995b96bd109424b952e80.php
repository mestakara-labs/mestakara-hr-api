
<?php use \App\Services\Payroll\PayrollExportText; ?>
<?php use \App\Services\Payroll\SpklDocument; ?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title><?php echo e($document['title']); ?> - <?php echo e($document['month_label']); ?></title>
    <?php echo $__env->make('payroll._styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <style>
        body { font-size: 7.5pt; }
        table.data td { padding: 1px 3px; }
        .identity td { padding: 0 4px 0 0; }
    </style>
</head>
<body>
<?php if($document['is_draft']): ?>
    <div class="watermark">DRAF</div>
<?php endif; ?>

<?php $__currentLoopData = $document['groups']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $group['blocks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="page">
            <table class="head">
                <tr>
                    <td style="width: 33%" class="company">PTP NUSANTARA I REGIONAL 2</td>
                    <td style="width: 34%" class="title"><?php echo e($document['title']); ?></td>
                    <td style="width: 33%" class="right bold">
                        BULAN : <?php echo e(mb_strtoupper($document['month_label'])); ?>

                        <?php if($document['is_draft']): ?>
                            <br><span class="draft-mark">DRAF</span>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>

            <table class="head identity">
                <tr><td style="width: 12%">No</td><td style="width: 40%">: <?php echo e($block['no']); ?></td><td style="width: 24%"></td><td></td></tr>
                <tr><td>Nama</td><td>: <?php echo e($block['name']); ?></td><td>Gaji Pokok 1 (satu) bulan</td><td>: Rp <?php echo e(PayrollExportText::rupiah($block['base_salary'])); ?></td></tr>
                <tr><td>Golongan</td><td>: <?php echo e($block['grade']); ?></td><td>Tarif per jam</td><td>: Rp <?php echo e(PayrollExportText::rupiah($block['hourly_rate'])); ?></td></tr>
                <tr><td>Bagian</td><td>: <?php echo e($block['section']); ?></td><td></td><td></td></tr>
            </table>

            <table class="data">
                <thead>
                    <tr>
                        <th rowspan="2">Hari</th>
                        <th rowspan="2">Tanggal</th>
                        <th colspan="3">Jumlah Jam</th>
                        <th colspan="2">Hari-Hari Biasa</th>
                        <th>Minggu/Libur</th>
                        <th rowspan="2" style="width: 30%">Uraian Pekerjaan</th>
                    </tr>
                    <tr>
                        <th>Dari</th><th>Sampai</th><th>Jumlah</th>
                        <th>Jam Pertama</th><th>Setelah Jam Pertama</th>
                        <th>7 Jam Pertama</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $block['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($day['day_name']); ?></td>
                            <td class="center"><?php echo e($day['date']); ?></td>
                            <td class="center"><?php echo e($day['from']); ?></td>
                            <td class="center"><?php echo e($day['to']); ?></td>
                            <td class="center"><?php echo e(SpklDocument::hours($day['hours'])); ?></td>
                            <td class="center"><?php echo e(SpklDocument::hours($day['first'])); ?></td>
                            <td class="center"><?php echo e(SpklDocument::hours($day['next'])); ?></td>
                            <td class="center"><?php echo e($day['holiday'] === null ? '' : $day['holiday']); ?></td>
                            <td><?php echo e($day['description']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="total">
                        <td colspan="4">Jumlah :</td>
                        <td class="center"><?php echo e(SpklDocument::hours($block['totals']['hours'])); ?></td>
                        <td class="center"><?php echo e(SpklDocument::hours($block['totals']['first'])); ?></td>
                        <td class="center"><?php echo e(SpklDocument::hours($block['totals']['next'])); ?></td>
                        <td class="center">0</td>
                        <td></td>
                    </tr>
                    <tr class="total">
                        <td colspan="5">kali</td>
                        <td class="center"><?php echo e(SpklDocument::hours($block['multipliers']['first'])); ?></td>
                        <td class="center"><?php echo e(SpklDocument::hours($block['multipliers']['next'])); ?></td>
                        <td class="center">-</td>
                        <td></td>
                    </tr>
                    <tr class="total">
                        <td colspan="5"></td>
                        <td class="center"><?php echo e(SpklDocument::hours($block['products']['first'])); ?></td>
                        <td class="center"><?php echo e(SpklDocument::hours($block['products']['next'])); ?></td>
                        <td class="center">0</td>
                        <td></td>
                    </tr>
                </tbody>
            </table>

            <p class="bold">
                Jumlah jam yang dibayar : <?php echo e(SpklDocument::hours($block['paid_hours'])); ?>

                x Rp. <?php echo e(PayrollExportText::rupiah($block['hourly_rate'])); ?> = Rp <?php echo e(PayrollExportText::rupiah($block['pay'])); ?>

            </p>

            <?php echo $__env->make('payroll._signatures', ['signature' => $block['signature']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH E:\Project\PTPN\agrowisata-mestakara\apps\mestakara-hr\api\resources\views/payroll/spkl.blade.php ENDPATH**/ ?>