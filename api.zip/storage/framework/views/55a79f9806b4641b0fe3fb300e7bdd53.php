
<?php use \App\Services\Payroll\PayrollExportDocument; ?>
<?php use \App\Services\Payroll\PayrollExportText; ?>
<?php
    $money = fn ($value) => PayrollExportText::rupiah((int) $value);
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title><?php echo e(PayrollExportDocument::TITLE); ?> - <?php echo e($document['month_label']); ?></title>
    <?php echo $__env->make('payroll._styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>
<?php if($document['is_draft']): ?>
    <div class="watermark">DRAF</div>
<?php endif; ?>

<?php $__currentLoopData = $document['sheets']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="page">
        <table class="head">
            <tr>
                <td style="width: 25%" class="company"><?php echo e(PayrollExportText::COMPANY); ?><br><?php echo e(PayrollExportText::UNIT); ?></td>
                <td style="width: 50%" class="title">
                    <?php if($sheet['type'] === 'group'): ?>
                        <?php echo e(PayrollExportDocument::TITLE); ?><br>UNIT : AGROWISATA
                    <?php elseif($sheet['type'] === 'rekap'): ?>
                        REKAPITULASI <?php echo e(PayrollExportDocument::TITLE); ?>

                    <?php else: ?>
                        PAYROLL <?php echo e(PayrollExportDocument::TITLE); ?>

                    <?php endif; ?>
                </td>
                <td style="width: 25%" class="right">
                    Bulan : <?php echo e($document['month_label']); ?><br>Hal. : <?php echo e($sheet['page']); ?>

                    <?php if($document['is_draft']): ?>
                        <br><span class="draft-mark">DRAF</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php if($sheet['type'] === 'group'): ?>
                <tr>
                    <td colspan="3" class="bold">
                        <?php echo e($sheet['group_label']); ?> : <?php echo e($sheet['name']); ?>

                        <?php if($sheet['sub_units'] !== ''): ?>
                            <br><span style="font-weight: normal">Sub Unit : <?php echo e($sheet['sub_units']); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
        </table>

        <?php if($sheet['type'] === 'group'): ?>
            <?php
                // Judul atas yang sama berturut-turut digabung (HARI KERJA, Tunjangan, Potongan).
                $topCells = [];
                foreach (PayrollExportDocument::GROUP_COLUMNS as [$key, $top, $sub]) {
                    $last = array_key_last($topCells);
                    if ($sub !== null && $last !== null && $topCells[$last]['title'] === $top && $topCells[$last]['sub']) {
                        $topCells[$last]['span']++;
                    } else {
                        $topCells[] = ['title' => $top, 'span' => 1, 'sub' => $sub !== null];
                    }
                }
            ?>
            <table class="data">
                <thead>
                    <tr>
                        <?php $__currentLoopData = $topCells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($cell['sub']): ?>
                                <th colspan="<?php echo e($cell['span']); ?>"><?php echo e($cell['title']); ?></th>
                            <?php else: ?>
                                <th rowspan="2"><?php echo e($cell['title']); ?></th>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <tr>
                        <?php $__currentLoopData = PayrollExportDocument::GROUP_COLUMNS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$key, $top, $sub]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($sub !== null): ?>
                                <th><?php echo e($sub); ?></th>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sheet['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php $__currentLoopData = PayrollExportDocument::GROUP_COLUMNS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$key, , , , $isMoney]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="<?php echo e($isMoney || in_array($key, ['no', 'hke', 'present_days'], true) ? 'num' : ''); ?>"><?php echo e($isMoney ? $money($row[$key]) : $row[$key]); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="total">
                        <td colspan="6" class="center">JUMLAH</td>
                        <?php $__currentLoopData = array_slice(PayrollExportDocument::GROUP_COLUMNS, 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$key, , , , $isMoney]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="num"><?php echo e($isMoney ? $money($sheet['totals'][$key] ?? 0) : ($sheet['totals'][$key] ?? '')); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tbody>
            </table>
        <?php else: ?>
            <?php
                $columns = $sheet['type'] === 'rekap' ? PayrollExportDocument::REKAP_COLUMNS : PayrollExportDocument::PAYROLL_COLUMNS;
                $labelSpan = $sheet['type'] === 'rekap' ? 2 : 6;
            ?>
            <table class="data">
                <thead>
                    <tr>
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [, $title]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($title); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sheet['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$key, , , $isMoney]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="<?php echo e($isMoney || is_int($row[$key]) ? 'num' : ''); ?>"><?php echo e($isMoney ? $money($row[$key]) : $row[$key]); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="total">
                        <td colspan="<?php echo e($labelSpan); ?>" class="center">JUMLAH</td>
                        <?php $__currentLoopData = array_slice($columns, $labelSpan); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$key, , , $isMoney]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="num"><?php echo e(array_key_exists($key, $sheet['totals']) ? ($isMoney ? $money($sheet['totals'][$key]) : $sheet['totals'][$key]) : ''); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>

        <?php if(isset($sheet['signature'])): ?>
            <?php echo $__env->make('payroll._signatures', ['signature' => $sheet['signature']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH E:\Project\PTPN\agrowisata-mestakara\apps\mestakara-hr\api\resources\views/payroll/daftar-upah.blade.php ENDPATH**/ ?>